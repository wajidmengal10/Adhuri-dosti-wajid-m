ادھوری دوستی — Wajid M.

یہ Android Studio / compatible Android build environment کے لیے ابتدائی سورس پروجیکٹ ہے۔

اہم:
- یہ ZIP تیار شدہ APK یا Play Store پر شائع شدہ ایپ نہیں ہے۔
- APK بنانے کے لیے Android build environment، Gradle اور compatible JDK درکار ہوں گے۔
- Play Store پر شائع کرنے کے لیے signed Android App Bundle (AAB)، Play Console اکاؤنٹ،
  ایپ کی تفصیلات، privacy/data safety معلومات اور Google کی جانچ درکار ہوتی ہے۔
- اگر موبائل پر build میں مسئلہ آئے تو error کا screenshot بھیجیں۔
