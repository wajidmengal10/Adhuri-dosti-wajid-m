package com.wajidm.adhooridosti

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Poem(val title: String, val body: String)

private val poems = listOf(
    Poem("دوستی کی یاد", "کچھ لوگ دل میں گھر بنا جاتے ہیں،\nپھر دور جا کر بھی بھلائے نہیں جاتے۔\nوقت بدلتا ہے، موسم بدلتے ہیں،\nمگر سچے رشتے دل سے مٹائے نہیں جاتے۔"),
    Poem("ادھوری دوستی", "کچھ باتیں رہ گئیں، کچھ وعدے رہ گئے،\nہم ہنستے رہے مگر آنسو بہہ گئے۔\nدوستی کا سفر بھی عجیب تھا،\nساتھ چلتے چلتے راستے جدا ہو گئے۔"),
    Poem("خاموشی", "خاموش لبوں پر کئی افسانے رہتے ہیں،\nبچھڑے ہوئے دوست دل کے خزانے رہتے ہیں۔\nجو لوٹ کر کبھی حال نہیں پوچھتے،\nوہ بھی یادوں میں پرانے رہتے ہیں۔")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppScreen() {
    var selected by remember { mutableStateOf<Int?>(null) }
    val context = LocalContext.current
    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("ادھوری دوستی", fontSize = 24.sp) })
        }) { padding ->
            if (selected == null) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text("کچھ یادیں، کچھ غزلیں، کچھ درد کی باتیں",
                            fontSize = 18.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))
                        Text("مصنف: واجد M.", modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center)
                    }
                    itemsIndexed(poems) { index, poem ->
                        Card(modifier = Modifier.fillMaxWidth().clickable { selected = index }) {
                            Column(Modifier.padding(16.dp)) {
                                Text(poem.title, fontSize = 21.sp)
                                Text("پڑھنے کے لیے یہاں دبائیں", modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
            } else {
                val poem = poems[selected!!]
                Column(Modifier.fillMaxSize().padding(padding).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("← واپس", modifier = Modifier.clickable { selected = null }, fontSize = 18.sp)
                    Text(poem.title, fontSize = 26.sp, modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center)
                    Text(poem.body, fontSize = 22.sp, lineHeight = 36.sp,
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Button(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, poem.title + "\n\n" + poem.body)
                        }
                        context.startActivity(Intent.createChooser(send, "شاعری شیئر کریں"))
                    }) { Text("شاعری شیئر کریں") }
                }
            }
        }
    }
}
